from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('maestros/<int:pk>/eliminar/', views.eliminar_maestro, name='eliminar_maestro'),
    path('alumnos/<int:pk>/eliminar/', views.eliminar_alumno, name='eliminar_alumno'),
]
